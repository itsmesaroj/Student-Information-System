﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace CollegeManagementSystem
{
    public partial class Students : Form
    {
        public Students()
        {
            InitializeComponent();
            ShowStudents();
            GetDepId();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\SAROJ MEHTA\OneDrive\Documents\College_Db.mdf"";Integrated Security=True;Connect Timeout=30");
        private void GetDepId()
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select DepNum from DepartmentTbl", Con);
            SqlDataReader Rdr;
            Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("DepNum", typeof(int));
            dt.Load(Rdr);
            DepIdCb.ValueMember = "DepNum";
            DepIdCb.DataSource = dt;
            Con.Close();
        }
        private void GetDepName()
        {
            Con.Open();
            string Query = "Select * from DepartmentTbl where DepNum=" + DepIdCb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(Query, Con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                DepNameTb.Text = dr["DepName"].ToString();
            }
            Con.Close();

        }
        private void ShowStudents()
        {
            Con.Open();
            string Query = "select * from StudentTbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            StdDGV.DataSource = ds.Tables[0];
            Con.Close();
            Reset();
        }
        private void Reset()
        {
            DepNameTb.Text = "";
            StdTb.Text = "";
            StdGenCb.SelectedIndex = -1;
            PhoneTb.Text = "";
            StdAddTb.Text = "";
            DepIdCb.SelectedIndex = -1;
           // UploadImage.Text = "";

        }
        private void Students_Load(object sender, EventArgs e)
        {

        }

        private void DepIdCb_SelectedIndexChanged(object sender, EventArgs e)
        {
            // nothing
        }

        private void DepIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetDepName();
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (StdTb.Text == "" || StdAddTb.Text == "" || DepNameTb.Text == "" || DepIdCb.SelectedIndex == -1 || PhoneTb.Text == "" || SemCb.SelectedIndex == -1 || StdGenCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                   

                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into StudentTbl(StName,StDOB,StGen,StAddress,StDepId,StDepName,Stphone,StSem)values(@SN,@SD,@SG,@SA,@SDI,@SDN,@SP,@SS)", Con);
                    cmd.Parameters.AddWithValue("@SN", StdTb.Text);
                    cmd.Parameters.AddWithValue("@SD", StdDOB.Value.Date);
                    cmd.Parameters.AddWithValue("@SG", StdGenCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@SA", StdAddTb.Text);
                    cmd.Parameters.AddWithValue("@SDI", DepIdCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@SDN", DepNameTb.Text);
                    cmd.Parameters.AddWithValue("@SP", PhoneTb.Text);
                    cmd.Parameters.AddWithValue("@SS", SemCb.SelectedItem.ToString());
                   // cmd.Parameters.AddWithValue("@IData", imageData);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Student Added");
                    Con.Close();
                    ShowStudents();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {

            if (Key == 0)
            {
                MessageBox.Show(" Select The Student");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Delete StudentTbl where StNum=@SKey", Con);
                    cmd.Parameters.AddWithValue("@SKey", Key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Student Deleted");
                    Con.Close();
                    ShowStudents();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        int Key = 0;
        private void StdDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            StdTb.Text = StdDGV.SelectedRows[0].Cells[1].Value.ToString();
            StdDOB.Text = StdDGV.SelectedRows[0].Cells[2].Value.ToString();
            StdGenCb.SelectedItem = StdDGV.SelectedRows[0].Cells[3].Value.ToString();
            StdAddTb.Text = StdDGV.SelectedRows[0].Cells[4].Value.ToString();
            DepIdCb.SelectedValue = StdDGV.SelectedRows[0].Cells[5].Value.ToString();
            DepNameTb.Text = StdDGV.SelectedRows[0].Cells[6].Value.ToString();
            PhoneTb.Text = StdDGV.SelectedRows[0].Cells[7].Value.ToString();
            SemCb.SelectedItem = StdDGV.SelectedRows[0].Cells[8].Value.ToString();
           


            if (StdTb.Text == "")
            {
                Key = 0;
                
            }
            else
            {
                Key = Convert.ToInt32(StdDGV.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            if (StdTb.Text == "" || StdAddTb.Text == "" || DepNameTb.Text == "" || DepIdCb.SelectedIndex == -1 || PhoneTb.Text == "" || SemCb.SelectedIndex == -1 || StdGenCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Update StudentTbl Set StName=@SN,StDOB=@SD,StGen=@SG,StAddress=@SA,StDepId=@SDI,StDepName=@SDN,Stphone=@SP,StSem=@SS where StNum=@SKey", Con);
                    cmd.Parameters.AddWithValue("@SN", StdTb.Text);
                    cmd.Parameters.AddWithValue("@SD", StdDOB.Value.Date);
                    cmd.Parameters.AddWithValue("@SG", StdGenCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@SA", StdAddTb.Text);
                    cmd.Parameters.AddWithValue("@SDI", DepIdCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@SDN", DepNameTb.Text);
                    cmd.Parameters.AddWithValue("@SP", PhoneTb.Text);
                    cmd.Parameters.AddWithValue("@SS", SemCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@SKey", Key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Student Updated");
                    Con.Close();
                    ShowStudents();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Departments Obj = new Departments();
            Obj.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Homes Obj = new Homes();
            Obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Students Obj = new Students();
            Obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Teachers Obj = new Teachers();
            Obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Courses Obj = new Courses();
            Obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Fees Obj = new Fees();
            Obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Logins obj = new Logins();
            obj.Show();
            this.Close();
        }

        
    }
}
