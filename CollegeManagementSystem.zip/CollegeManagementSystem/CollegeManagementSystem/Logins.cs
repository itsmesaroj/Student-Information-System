﻿using System;
using System.Windows.Forms;

namespace CollegeManagementSystem
{
    public partial class Logins : Form
    {
        public Logins()
        {
            InitializeComponent();

            // Set the initial time
            label4.Text = DateTime.Now.ToString("hh:mm:ss.fff tt");

            // Create a timer to update the clock every second
            var timer = new Timer();
            timer.Interval = 10; // milliseconds
            timer.Tick += new EventHandler(this.timer1_Tick);
            timer.Start();
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if (UnameTb.Text == "" || PasswordTb.Text == "")
            {
                MessageBox.Show("Enter Both User Name and Password");

            }
            else if (UnameTb.Text == "Admin" || UnameTb.Text=="Saroj" || UnameTb.Text=="Ishika" && PasswordTb.Text == "Password" || PasswordTb.Text=="Mehta")
            {
                Homes Obj = new Homes();
                Obj.Show();
                this.Hide();

                MessageBox.Show("Login Successful");
            }
            else
            {
                MessageBox.Show("Wrong UserName Or Password ");
                UnameTb.Text = "";
                PasswordTb.Text = "";
                MessageBox.Show("Login Failed");
            }
        }

        private void ResetBtb_Click(object sender, EventArgs e)
        {
            UnameTb.Text = "";
            PasswordTb.Text = "";
        }

        private void Logins_Load(object sender, EventArgs e) //CancleBtn
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
            //if (MessageBox.Show("Do you want to close the application?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.No)
            // {
            //Application.Exit();
            //   e.Cancel = true;
            //  }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label4.Text = DateTime.Now.ToString("hh:mm:ss.fff tt");
        }
    }
}
