﻿namespace CollegeManagementSystem
{
    partial class Fees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Fees));
            this.StIdCb = new System.Windows.Forms.ComboBox();
            this.FeesAmtTb = new System.Windows.Forms.TextBox();
            this.DepNameTb = new System.Windows.Forms.TextBox();
            this.StdNameTb = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bunifuElipse5 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse3 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse2 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse4 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.label12 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.TrIdCb = new System.Windows.Forms.ComboBox();
            this.SalaryAmtTb = new System.Windows.Forms.TextBox();
            this.TrNameTb = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.FeesDGV = new Guna.UI.WinForms.GunaDataGridView();
            this.SalaryDGV = new Guna.UI.WinForms.GunaDataGridView();
            this.SemCb = new System.Windows.Forms.ComboBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.SalaryPeriod = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.SalResetBtn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.SalPayBtn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.FeeResetBtn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.FeePayBtn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.FeesDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SalaryDGV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // StIdCb
            // 
            this.StIdCb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.StIdCb.FormattingEnabled = true;
            this.StIdCb.Location = new System.Drawing.Point(229, 201);
            this.StIdCb.Name = "StIdCb";
            this.StIdCb.Size = new System.Drawing.Size(121, 31);
            this.StIdCb.TabIndex = 116;
            this.StIdCb.SelectionChangeCommitted += new System.EventHandler(this.StIdCb_SelectionChangeCommitted);
            // 
            // FeesAmtTb
            // 
            this.FeesAmtTb.BackColor = System.Drawing.Color.White;
            this.FeesAmtTb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FeesAmtTb.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.FeesAmtTb.Location = new System.Drawing.Point(568, 204);
            this.FeesAmtTb.Name = "FeesAmtTb";
            this.FeesAmtTb.Size = new System.Drawing.Size(130, 30);
            this.FeesAmtTb.TabIndex = 113;
            // 
            // DepNameTb
            // 
            this.DepNameTb.BackColor = System.Drawing.Color.White;
            this.DepNameTb.Enabled = false;
            this.DepNameTb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DepNameTb.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.DepNameTb.Location = new System.Drawing.Point(228, 276);
            this.DepNameTb.Name = "DepNameTb";
            this.DepNameTb.Size = new System.Drawing.Size(122, 30);
            this.DepNameTb.TabIndex = 114;
            // 
            // StdNameTb
            // 
            this.StdNameTb.BackColor = System.Drawing.Color.White;
            this.StdNameTb.Enabled = false;
            this.StdNameTb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StdNameTb.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.StdNameTb.Location = new System.Drawing.Point(365, 202);
            this.StdNameTb.Name = "StdNameTb";
            this.StdNameTb.Size = new System.Drawing.Size(193, 30);
            this.StdNameTb.TabIndex = 112;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Location = new System.Drawing.Point(241, 366);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(450, 5);
            this.panel2.TabIndex = 111;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Black;
            this.panel11.Location = new System.Drawing.Point(88, 481);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(45, 3);
            this.panel11.TabIndex = 110;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.RosyBrown;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Green;
            this.label17.Location = new System.Drawing.Point(571, 62);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(101, 23);
            this.label17.TabIndex = 109;
            this.label17.Text = "Biratnagar";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.RosyBrown;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Green;
            this.label16.Location = new System.Drawing.Point(501, 30);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(266, 32);
            this.label16.TabIndex = 108;
            this.label16.Text = "Birat Kshitiz College";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Maroon;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label8.Location = new System.Drawing.Point(84, 319);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 23);
            this.label8.TabIndex = 107;
            this.label8.Text = "Teacher";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Maroon;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label7.Location = new System.Drawing.Point(84, 459);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 23);
            this.label7.TabIndex = 106;
            this.label7.Text = "Fees";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Maroon;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label6.Location = new System.Drawing.Point(84, 591);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 23);
            this.label6.TabIndex = 103;
            this.label6.Text = "Logout";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Maroon;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label5.Location = new System.Drawing.Point(84, 389);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 23);
            this.label5.TabIndex = 99;
            this.label5.Text = "Courses";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Blue;
            this.label13.Location = new System.Drawing.Point(225, 173);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(97, 23);
            this.label13.TabIndex = 92;
            this.label13.Text = "Student Id";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Blue;
            this.label11.Location = new System.Drawing.Point(564, 175);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 23);
            this.label11.TabIndex = 96;
            this.label11.Text = "Amount";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(225, 247);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(111, 23);
            this.label10.TabIndex = 97;
            this.label10.Text = "Department";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(358, 173);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(129, 23);
            this.label9.TabIndex = 95;
            this.label9.Text = "Student Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Maroon;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label3.Location = new System.Drawing.Point(84, 241);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 23);
            this.label3.TabIndex = 94;
            this.label3.Text = "Department";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Maroon;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label2.Location = new System.Drawing.Point(84, 172);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 23);
            this.label2.TabIndex = 89;
            this.label2.Text = "Student";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Maroon;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label1.Location = new System.Drawing.Point(84, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 23);
            this.label1.TabIndex = 87;
            this.label1.Text = "Home";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // bunifuElipse5
            // 
            this.bunifuElipse5.ElipseRadius = 35;
            this.bunifuElipse5.TargetControl = this;
            // 
            // bunifuElipse3
            // 
            this.bunifuElipse3.ElipseRadius = 50;
            this.bunifuElipse3.TargetControl = this;
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 40;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuElipse2
            // 
            this.bunifuElipse2.ElipseRadius = 50;
            this.bunifuElipse2.TargetControl = this;
            // 
            // bunifuElipse4
            // 
            this.bunifuElipse4.ElipseRadius = 35;
            this.bunifuElipse4.TargetControl = this;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Blue;
            this.label12.Location = new System.Drawing.Point(413, 247);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 23);
            this.label12.TabIndex = 127;
            this.label12.Text = "Period";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlText;
            this.panel3.Location = new System.Drawing.Point(223, 146);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(450, 5);
            this.panel3.TabIndex = 129;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.RosyBrown;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Green;
            this.label14.Location = new System.Drawing.Point(399, 123);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 23);
            this.label14.TabIndex = 109;
            this.label14.Text = "Fees";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Blue;
            this.panel4.Location = new System.Drawing.Point(706, 147);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(5, 490);
            this.panel4.TabIndex = 130;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ControlText;
            this.panel5.Location = new System.Drawing.Point(737, 147);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(460, 5);
            this.panel5.TabIndex = 146;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Blue;
            this.label15.Location = new System.Drawing.Point(901, 247);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 23);
            this.label15.TabIndex = 144;
            this.label15.Text = "Period";
            // 
            // TrIdCb
            // 
            this.TrIdCb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.TrIdCb.FormattingEnabled = true;
            this.TrIdCb.Location = new System.Drawing.Point(769, 202);
            this.TrIdCb.Name = "TrIdCb";
            this.TrIdCb.Size = new System.Drawing.Size(121, 31);
            this.TrIdCb.TabIndex = 140;
            this.TrIdCb.SelectionChangeCommitted += new System.EventHandler(this.TrIdCb_SelectionChangeCommitted);
            // 
            // SalaryAmtTb
            // 
            this.SalaryAmtTb.BackColor = System.Drawing.Color.White;
            this.SalaryAmtTb.Enabled = false;
            this.SalaryAmtTb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalaryAmtTb.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.SalaryAmtTb.Location = new System.Drawing.Point(768, 277);
            this.SalaryAmtTb.Name = "SalaryAmtTb";
            this.SalaryAmtTb.Size = new System.Drawing.Size(122, 30);
            this.SalaryAmtTb.TabIndex = 139;
            // 
            // TrNameTb
            // 
            this.TrNameTb.BackColor = System.Drawing.Color.White;
            this.TrNameTb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrNameTb.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.TrNameTb.Location = new System.Drawing.Point(905, 203);
            this.TrNameTb.Name = "TrNameTb";
            this.TrNameTb.Size = new System.Drawing.Size(263, 30);
            this.TrNameTb.TabIndex = 137;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel6.Location = new System.Drawing.Point(735, 367);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(460, 5);
            this.panel6.TabIndex = 136;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.RosyBrown;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Green;
            this.label18.Location = new System.Drawing.Point(913, 124);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(64, 23);
            this.label18.TabIndex = 135;
            this.label18.Text = "Salary";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Blue;
            this.label19.Location = new System.Drawing.Point(765, 174);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(100, 23);
            this.label19.TabIndex = 131;
            this.label19.Text = "Teacher Id";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Blue;
            this.label21.Location = new System.Drawing.Point(765, 248);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(76, 23);
            this.label21.TabIndex = 134;
            this.label21.Text = "Amount";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Blue;
            this.label22.Location = new System.Drawing.Point(898, 174);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(132, 23);
            this.label22.TabIndex = 132;
            this.label22.Text = "Teacher Name";
            // 
            // FeesDGV
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            this.FeesDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.FeesDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.FeesDGV.BackgroundColor = System.Drawing.Color.White;
            this.FeesDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FeesDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.FeesDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.FeesDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.FeesDGV.ColumnHeadersHeight = 27;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.ForestGreen;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.FeesDGV.DefaultCellStyle = dataGridViewCellStyle6;
            this.FeesDGV.EnableHeadersVisualStyles = false;
            this.FeesDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.FeesDGV.Location = new System.Drawing.Point(241, 374);
            this.FeesDGV.Name = "FeesDGV";
            this.FeesDGV.RowHeadersVisible = false;
            this.FeesDGV.RowHeadersWidth = 51;
            this.FeesDGV.RowTemplate.Height = 24;
            this.FeesDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.FeesDGV.Size = new System.Drawing.Size(450, 262);
            this.FeesDGV.TabIndex = 147;
            this.FeesDGV.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.FeesDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.FeesDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.FeesDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.FeesDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.FeesDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.FeesDGV.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.FeesDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.FeesDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Black;
            this.FeesDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.FeesDGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FeesDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.FeesDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.FeesDGV.ThemeStyle.HeaderStyle.Height = 27;
            this.FeesDGV.ThemeStyle.ReadOnly = false;
            this.FeesDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.FeesDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.FeesDGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FeesDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.ForestGreen;
            this.FeesDGV.ThemeStyle.RowsStyle.Height = 24;
            this.FeesDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.FeesDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // SalaryDGV
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.SalaryDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.SalaryDGV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.SalaryDGV.BackgroundColor = System.Drawing.Color.White;
            this.SalaryDGV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SalaryDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.SalaryDGV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SalaryDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.SalaryDGV.ColumnHeadersHeight = 27;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.ForestGreen;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.SalaryDGV.DefaultCellStyle = dataGridViewCellStyle3;
            this.SalaryDGV.EnableHeadersVisualStyles = false;
            this.SalaryDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.SalaryDGV.Location = new System.Drawing.Point(735, 374);
            this.SalaryDGV.Name = "SalaryDGV";
            this.SalaryDGV.RowHeadersVisible = false;
            this.SalaryDGV.RowHeadersWidth = 51;
            this.SalaryDGV.RowTemplate.Height = 24;
            this.SalaryDGV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.SalaryDGV.Size = new System.Drawing.Size(468, 262);
            this.SalaryDGV.TabIndex = 148;
            this.SalaryDGV.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.SalaryDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.SalaryDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.SalaryDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.SalaryDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.SalaryDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.SalaryDGV.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.SalaryDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.SalaryDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.Black;
            this.SalaryDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.SalaryDGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalaryDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.SalaryDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.SalaryDGV.ThemeStyle.HeaderStyle.Height = 27;
            this.SalaryDGV.ThemeStyle.ReadOnly = false;
            this.SalaryDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.SalaryDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.SalaryDGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalaryDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.ForestGreen;
            this.SalaryDGV.ThemeStyle.RowsStyle.Height = 24;
            this.SalaryDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.SalaryDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // SemCb
            // 
            this.SemCb.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.SemCb.FormattingEnabled = true;
            this.SemCb.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.SemCb.Location = new System.Drawing.Point(417, 281);
            this.SemCb.Name = "SemCb";
            this.SemCb.Size = new System.Drawing.Size(162, 31);
            this.SemCb.TabIndex = 149;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Maroon;
            this.panel7.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.panel7.Location = new System.Drawing.Point(-4, -2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(207, 652);
            this.panel7.TabIndex = 150;
            // 
            // SalaryPeriod
            // 
            this.SalaryPeriod.BackColor = System.Drawing.Color.Transparent;
            this.SalaryPeriod.BorderRadius = 1;
            this.SalaryPeriod.Color = System.Drawing.Color.DodgerBlue;
            this.SalaryPeriod.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thin;
            this.SalaryPeriod.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.SalaryPeriod.DisabledColor = System.Drawing.Color.Gray;
            this.SalaryPeriod.DisplayWeekNumbers = false;
            this.SalaryPeriod.DPHeight = 0;
            this.SalaryPeriod.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.SalaryPeriod.FillDatePicker = true;
            this.SalaryPeriod.Font = new System.Drawing.Font("Arial Narrow", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalaryPeriod.ForeColor = System.Drawing.Color.White;
            this.SalaryPeriod.Icon = ((System.Drawing.Image)(resources.GetObject("SalaryPeriod.Icon")));
            this.SalaryPeriod.IconColor = System.Drawing.Color.White;
            this.SalaryPeriod.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.SalaryPeriod.LeftTextMargin = 5;
            this.SalaryPeriod.Location = new System.Drawing.Point(905, 275);
            this.SalaryPeriod.MinimumSize = new System.Drawing.Size(4, 32);
            this.SalaryPeriod.Name = "SalaryPeriod";
            this.SalaryPeriod.Size = new System.Drawing.Size(263, 32);
            this.SalaryPeriod.TabIndex = 145;
            this.SalaryPeriod.Value = new System.DateTime(2023, 3, 2, 16, 54, 0, 0);
            // 
            // SalResetBtn
            // 
            this.SalResetBtn.ActiveBorderThickness = 1;
            this.SalResetBtn.ActiveCornerRadius = 20;
            this.SalResetBtn.ActiveFillColor = System.Drawing.Color.Blue;
            this.SalResetBtn.ActiveForecolor = System.Drawing.Color.RosyBrown;
            this.SalResetBtn.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.SalResetBtn.BackColor = System.Drawing.Color.RosyBrown;
            this.SalResetBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SalResetBtn.BackgroundImage")));
            this.SalResetBtn.ButtonText = "Reset";
            this.SalResetBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SalResetBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.SalResetBtn.ForeColor = System.Drawing.Color.SeaGreen;
            this.SalResetBtn.IdleBorderThickness = 1;
            this.SalResetBtn.IdleCornerRadius = 20;
            this.SalResetBtn.IdleFillColor = System.Drawing.Color.White;
            this.SalResetBtn.IdleForecolor = System.Drawing.Color.Blue;
            this.SalResetBtn.IdleLineColor = System.Drawing.Color.Blue;
            this.SalResetBtn.Location = new System.Drawing.Point(963, 321);
            this.SalResetBtn.Margin = new System.Windows.Forms.Padding(5);
            this.SalResetBtn.Name = "SalResetBtn";
            this.SalResetBtn.Size = new System.Drawing.Size(121, 46);
            this.SalResetBtn.TabIndex = 142;
            this.SalResetBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.SalResetBtn.Click += new System.EventHandler(this.SalResetBtn_Click);
            // 
            // SalPayBtn
            // 
            this.SalPayBtn.ActiveBorderThickness = 1;
            this.SalPayBtn.ActiveCornerRadius = 20;
            this.SalPayBtn.ActiveFillColor = System.Drawing.Color.Blue;
            this.SalPayBtn.ActiveForecolor = System.Drawing.Color.RosyBrown;
            this.SalPayBtn.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.SalPayBtn.BackColor = System.Drawing.Color.RosyBrown;
            this.SalPayBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SalPayBtn.BackgroundImage")));
            this.SalPayBtn.ButtonText = "Pay";
            this.SalPayBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SalPayBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.SalPayBtn.ForeColor = System.Drawing.Color.Blue;
            this.SalPayBtn.IdleBorderThickness = 1;
            this.SalPayBtn.IdleCornerRadius = 20;
            this.SalPayBtn.IdleFillColor = System.Drawing.Color.White;
            this.SalPayBtn.IdleForecolor = System.Drawing.Color.Blue;
            this.SalPayBtn.IdleLineColor = System.Drawing.Color.Blue;
            this.SalPayBtn.Location = new System.Drawing.Point(773, 321);
            this.SalPayBtn.Margin = new System.Windows.Forms.Padding(5);
            this.SalPayBtn.Name = "SalPayBtn";
            this.SalPayBtn.Size = new System.Drawing.Size(121, 46);
            this.SalPayBtn.TabIndex = 141;
            this.SalPayBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.SalPayBtn.Click += new System.EventHandler(this.SalPayBtn_Click);
            // 
            // FeeResetBtn
            // 
            this.FeeResetBtn.ActiveBorderThickness = 1;
            this.FeeResetBtn.ActiveCornerRadius = 20;
            this.FeeResetBtn.ActiveFillColor = System.Drawing.Color.Blue;
            this.FeeResetBtn.ActiveForecolor = System.Drawing.Color.RosyBrown;
            this.FeeResetBtn.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.FeeResetBtn.BackColor = System.Drawing.Color.RosyBrown;
            this.FeeResetBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("FeeResetBtn.BackgroundImage")));
            this.FeeResetBtn.ButtonText = "Reset";
            this.FeeResetBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FeeResetBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.FeeResetBtn.ForeColor = System.Drawing.Color.SeaGreen;
            this.FeeResetBtn.IdleBorderThickness = 1;
            this.FeeResetBtn.IdleCornerRadius = 20;
            this.FeeResetBtn.IdleFillColor = System.Drawing.Color.White;
            this.FeeResetBtn.IdleForecolor = System.Drawing.Color.Blue;
            this.FeeResetBtn.IdleLineColor = System.Drawing.Color.Blue;
            this.FeeResetBtn.Location = new System.Drawing.Point(474, 320);
            this.FeeResetBtn.Margin = new System.Windows.Forms.Padding(5);
            this.FeeResetBtn.Name = "FeeResetBtn";
            this.FeeResetBtn.Size = new System.Drawing.Size(121, 46);
            this.FeeResetBtn.TabIndex = 119;
            this.FeeResetBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.FeeResetBtn.Click += new System.EventHandler(this.FeeResetBtn_Click);
            // 
            // FeePayBtn
            // 
            this.FeePayBtn.ActiveBorderThickness = 1;
            this.FeePayBtn.ActiveCornerRadius = 20;
            this.FeePayBtn.ActiveFillColor = System.Drawing.Color.Blue;
            this.FeePayBtn.ActiveForecolor = System.Drawing.Color.RosyBrown;
            this.FeePayBtn.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.FeePayBtn.BackColor = System.Drawing.Color.RosyBrown;
            this.FeePayBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("FeePayBtn.BackgroundImage")));
            this.FeePayBtn.ButtonText = "Pay";
            this.FeePayBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FeePayBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.FeePayBtn.ForeColor = System.Drawing.Color.Blue;
            this.FeePayBtn.IdleBorderThickness = 1;
            this.FeePayBtn.IdleCornerRadius = 20;
            this.FeePayBtn.IdleFillColor = System.Drawing.Color.White;
            this.FeePayBtn.IdleForecolor = System.Drawing.Color.Blue;
            this.FeePayBtn.IdleLineColor = System.Drawing.Color.Blue;
            this.FeePayBtn.Location = new System.Drawing.Point(284, 320);
            this.FeePayBtn.Margin = new System.Windows.Forms.Padding(5);
            this.FeePayBtn.Name = "FeePayBtn";
            this.FeePayBtn.Size = new System.Drawing.Size(121, 46);
            this.FeePayBtn.TabIndex = 118;
            this.FeePayBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.FeePayBtn.Click += new System.EventHandler(this.FeePayBtn_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::CollegeManagementSystem.Properties.Resources.courses;
            this.pictureBox6.Location = new System.Drawing.Point(35, 378);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(37, 38);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 98;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::CollegeManagementSystem.Properties.Resources.professor;
            this.pictureBox9.Location = new System.Drawing.Point(35, 308);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(37, 38);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 105;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::CollegeManagementSystem.Properties.Resources.fee;
            this.pictureBox8.Location = new System.Drawing.Point(35, 448);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(37, 38);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 104;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::CollegeManagementSystem.Properties.Resources.logout;
            this.pictureBox7.Location = new System.Drawing.Point(35, 578);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(37, 38);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 101;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::CollegeManagementSystem.Properties.Resources.home;
            this.pictureBox2.Location = new System.Drawing.Point(35, 96);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(37, 38);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 86;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::CollegeManagementSystem.Properties.Resources.department;
            this.pictureBox4.Location = new System.Drawing.Point(35, 229);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(37, 38);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 90;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.Image = global::CollegeManagementSystem.Properties.Resources.student1;
            this.pictureBox3.Location = new System.Drawing.Point(35, 160);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(37, 38);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 88;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::CollegeManagementSystem.Properties.Resources.collegeLogo;
            this.pictureBox1.Location = new System.Drawing.Point(35, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(57, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 85;
            this.pictureBox1.TabStop = false;
            // 
            // Fees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1226, 648);
            this.Controls.Add(this.SemCb);
            this.Controls.Add(this.SalaryDGV);
            this.Controls.Add(this.FeesDGV);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.SalaryPeriod);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.SalResetBtn);
            this.Controls.Add(this.SalPayBtn);
            this.Controls.Add(this.TrIdCb);
            this.Controls.Add(this.SalaryAmtTb);
            this.Controls.Add(this.TrNameTb);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.FeeResetBtn);
            this.Controls.Add(this.FeePayBtn);
            this.Controls.Add(this.StIdCb);
            this.Controls.Add(this.FeesAmtTb);
            this.Controls.Add(this.DepNameTb);
            this.Controls.Add(this.StdNameTb);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel7);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Fees";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fees";
            this.Load += new System.EventHandler(this.Fees_Load);
            ((System.ComponentModel.ISupportInitialize)(this.FeesDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SalaryDGV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Bunifu.Framework.UI.BunifuThinButton2 FeeResetBtn;
        private Bunifu.Framework.UI.BunifuThinButton2 FeePayBtn;
        private System.Windows.Forms.ComboBox StIdCb;
        private System.Windows.Forms.TextBox FeesAmtTb;
        private System.Windows.Forms.TextBox DepNameTb;
        private System.Windows.Forms.TextBox StdNameTb;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse3;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse2;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel5;
        private Bunifu.UI.WinForms.BunifuDatePicker SalaryPeriod;
        private System.Windows.Forms.Label label15;
        private Bunifu.Framework.UI.BunifuThinButton2 SalResetBtn;
        private Bunifu.Framework.UI.BunifuThinButton2 SalPayBtn;
        private System.Windows.Forms.ComboBox TrIdCb;
        private System.Windows.Forms.TextBox SalaryAmtTb;
        private System.Windows.Forms.TextBox TrNameTb;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private Guna.UI.WinForms.GunaDataGridView FeesDGV;
        private Guna.UI.WinForms.GunaDataGridView SalaryDGV;
        private System.Windows.Forms.ComboBox SemCb;
        private System.Windows.Forms.Panel panel7;
    }
}