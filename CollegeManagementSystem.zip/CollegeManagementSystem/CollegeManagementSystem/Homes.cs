﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeManagementSystem
{
    public partial class Homes : Form
    {
        public Homes()
        {
            InitializeComponent();
            CountStudents();
            CountTr();
            CountDepartment();
            SumIncome();
            SumSalary();
        }
       
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\SAROJ MEHTA\OneDrive\Documents\College_Db.mdf"";Integrated Security=True;Connect Timeout=30");
        private void SumIncome()
        {
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Sum(FAmount) from FeesTbl", Con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            FeesLbl.Text = "RS " +dt.Rows[0][0].ToString();
            Con.Close();
        }
        private void SumSalary()
        {
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select Sum(TrSalary) from SalaryTbl", Con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            SalaryLbl.Text = "RS " +dt.Rows[0][0].ToString();
            Con.Close();
        }
        private void CountStudents()
        {
            Con.Open();
            SqlDataAdapter sda=new SqlDataAdapter("Select Count(*) from StudentTbl",Con);
            DataTable dt= new DataTable();  
            sda.Fill(dt);
            StdLbl.Text = dt.Rows[0][0].ToString();
            Con.Close();
        }
        
        private void CountTr()
        {
            Con.Open();
            SqlDataAdapter sda=new SqlDataAdapter("Select Count(*) from TeacherTbl",Con);
            DataTable dt= new DataTable();  
            sda.Fill(dt);
            FacultyLbl.Text = dt.Rows[0][0].ToString();
            Con.Close();
        } private void CountDepartment()
        {
            Con.Open();
            SqlDataAdapter sda=new SqlDataAdapter("Select Count(*) from DepartmentTbl",Con);
            DataTable dt= new DataTable();  
            sda.Fill(dt);
            DepLbl.Text = dt.Rows[0][0].ToString();
            Con.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Teachers Obj = new Teachers();
            Obj.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            Students Obj = new Students();
            Obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Courses Obj = new Courses();
            Obj.Show();
            this.Hide();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            Fees Obj = new Fees();
            Obj.Show();
            this.Hide();
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            Students Obj= new Students();
            Obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Departments Obj = new Departments();
            Obj.Show();
            this.Hide();
        }

        private void label4_Click_1(object sender, EventArgs e)
        {
            //Salary Obj = new Salary ();
            //Obj.Show();
            //this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Logins obj= new Logins();  
            obj.Show();
            this.Close();
        }

      //  private void label4_Click_2(object sender, EventArgs e)
       // {

        //}

        //private void panel1_Paint(object sender, PaintEventArgs e)
        //{

        //}
    }
}
