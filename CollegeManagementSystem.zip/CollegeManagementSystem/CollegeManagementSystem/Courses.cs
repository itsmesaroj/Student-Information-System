﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;

namespace CollegeManagementSystem
{
    public partial class Courses : Form
    {
        public Courses()
        {
            InitializeComponent();
            GetDepId();
            GetTrId();
            ShowCourse();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\SAROJ MEHTA\OneDrive\Documents\College_Db.mdf"";Integrated Security=True;Connect Timeout=30");
        private void GetTrId()
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select TrNum from TeacherTbl", Con);
            SqlDataReader Rdr;
            Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("TrNum", typeof(int));
            dt.Load(Rdr);
            TrIdCb.ValueMember = "TrNum";
            TrIdCb.DataSource = dt;
            Con.Close();
        }
        private void GetTrName()
        {
            Con.Open();
            string Query = "Select * from TeacherTbl where TrNum=" + TrIdCb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(Query, Con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                TrTb.Text = dr["TrName"].ToString();
            }
            Con.Close();

        }
        private void GetDepId()
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select DepNum from DepartmentTbl", Con);
            SqlDataReader Rdr;
            Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("DepNum", typeof(int));
            dt.Load(Rdr);
            DepIdCb.ValueMember = "DepNum";
            DepIdCb.DataSource = dt;
            Con.Close();
        }
        private void GetDepName()
        {
            Con.Open();
            string Query = "Select * from DepartmentTbl where DepNum=" + DepIdCb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(Query, Con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                DepNameTb.Text = dr["DepName"].ToString();
            }
            Con.Close();

        }
        private void ShowCourse()
        {
            Con.Open();
            string Query = "select * from CourseTbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            CourseDGV.DataSource = ds.Tables[0];
            Con.Close();
            Reset();
        }
        private void Reset()
        {
            DepNameTb.Text = "";
            CNameTb.Text = "";
            TrIdCb.SelectedIndex = -1;
            DurationTb.Text = "";
            TrTb.Text = "";
            DepIdCb.SelectedIndex = -1;

        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (CNameTb.Text == "" || DurationTb.Text == "" || DepNameTb.Text == "" || DepIdCb.SelectedIndex == -1 || TrTb.Text == "" || TrIdCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into CourseTbl(CName,CDuration,CDepId,CDepName,CTrId,CTrName)values(@CN,@CD,@CDI,@CDN,@CTI,@CTN)", Con);
                    cmd.Parameters.AddWithValue("@CN", CNameTb.Text);
                    cmd.Parameters.AddWithValue("@CD", DurationTb.Text);
                    cmd.Parameters.AddWithValue("@CDI", DepIdCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@CDN", DepNameTb.Text);
                    cmd.Parameters.AddWithValue("@CTI", TrIdCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@CTN", TrTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Course Added");
                    Con.Close();
                    ShowCourse();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void DepIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetDepName();
        }

        private void TrIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetTrName();  
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            if (CNameTb.Text == "" || DurationTb.Text == "" || DepNameTb.Text == "" || DepIdCb.SelectedIndex == -1 || TrTb.Text == "" || TrIdCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Update CourseTbl Set CName=@CN,CDuration=@CD,CDepId=@CDI,CDepName=@CDN,CTrId=@CTI,CTrName=@CTN where CNum=@CKey", Con);
                    cmd.Parameters.AddWithValue("@CN", CNameTb.Text);
                    cmd.Parameters.AddWithValue("@CD", DurationTb.Text);
                    cmd.Parameters.AddWithValue("@CDI", DepIdCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@CDN", DepNameTb.Text);
                    cmd.Parameters.AddWithValue("@CTI", TrIdCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@CTN", TrTb.Text);
                    cmd.Parameters.AddWithValue("@CKey", Key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Course Updated");
                    Con.Close();
                    ShowCourse();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        int Key = 0;
        private void CourseDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            CNameTb.Text = CourseDGV.SelectedRows[0].Cells[1].Value.ToString();
            DurationTb.Text = CourseDGV.SelectedRows[0].Cells[2].Value.ToString();
            DepIdCb.SelectedValue = CourseDGV.SelectedRows[0].Cells[3].Value.ToString();
            DepNameTb.Text = CourseDGV.SelectedRows[0].Cells[4].Value.ToString();
            TrIdCb.SelectedValue = CourseDGV.SelectedRows[0].Cells[5].Value.ToString();
            TrTb.Text = CourseDGV.SelectedRows[0].Cells[6].Value.ToString();
            if (CNameTb.Text == "")
            {
                Key = 0;

            }
            else
            {
                Key = Convert.ToInt32(CourseDGV.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {

            if (Key == 0)
            {
                MessageBox.Show(" Select The Course");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Delete CourseTbl where CNum=@CKey", Con);
                    cmd.Parameters.AddWithValue("@CKey", Key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Course Deleted");
                    Con.Close();
                    ShowCourse();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Homes Obj = new Homes();
            Obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Students Obj = new Students();
            Obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Departments Obj = new Departments();
            Obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Teachers Obj = new Teachers();
            Obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Courses Obj = new Courses();
            Obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Fees Obj = new Fees();
            Obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Logins obj = new Logins();
            obj.Show();
            this.Close();
        }
    }
}
