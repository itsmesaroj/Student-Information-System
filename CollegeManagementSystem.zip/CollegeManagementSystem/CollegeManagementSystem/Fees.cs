﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CollegeManagementSystem
{
    public partial class Fees : Form
    {
        public Fees()
        {
            InitializeComponent();
            ShowFees();
            GetStdId();
            GetStName();
            ShowSalary();
            GetTrId();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\SAROJ MEHTA\OneDrive\Documents\College_Db.mdf"";Integrated Security=True;Connect Timeout=30");
        private void ShowFees()
        {
            Con.Open();
            string Query = "select * from FeesTbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            FeesDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void ShowSalary()
        {
            Con.Open();
            string Query = "select * from SalaryTbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            SalaryDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void Reset()
        {
            StdNameTb.Text = "";
            StIdCb.SelectedIndex = -1;
            DepNameTb.Text = "";

        }
        private void ResetSalary()
        {
            SalaryAmtTb.Text = "";
            TrIdCb.SelectedIndex = -1;
            TrNameTb.Text = "";

        }

        private void GetStdId()
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select StNum from StudentTbl", Con);
            SqlDataReader Rdr;
            Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("StNum", typeof(int));
            dt.Load(Rdr);
            StIdCb.ValueMember = "StNum";
            StIdCb.DataSource = dt;
            Con.Close();
        }
        private void GetStName()
        {
            Con.Open();
            string Query = "Select * from StudentTbl where StNum=" + StIdCb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(Query, Con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                StdNameTb.Text = dr["StName"].ToString();
                DepNameTb.Text = dr["StDepName"].ToString();
            }
            Con.Close();

        }
        private void GetTrId()
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select TrNum from TeacherTbl", Con);
            SqlDataReader Rdr;
            Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("TrNum", typeof(int));
            dt.Load(Rdr);
            TrIdCb.ValueMember = "TrNum";
            TrIdCb.DataSource = dt;
            Con.Close();
        }
        private void GetTrName()
        {
            Con.Open();
            string Query = "Select * from TeacherTbl where TrNum=" + TrIdCb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(Query, Con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                TrNameTb.Text = dr["TrName"].ToString();
                SalaryAmtTb.Text = dr["TrSalary"].ToString();
            }
            Con.Close();

        }
        private void Fees_Load(object sender, EventArgs e)
        {
            //nothing
        }

        private void FeePayBtn_Click(object sender, EventArgs e)
        {
            if (StdNameTb.Text == "" || FeesAmtTb.Text == "" || DepNameTb.Text == "" || DepNameTb.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into FeesTbl(StNum,StName,StDep,FPeriod,FAmount,PayDate)values(@SN,@SNa,@SD,@FP,@FA,@PDa)", Con);
                    cmd.Parameters.AddWithValue("@SN", StIdCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@SNa", StdNameTb.Text);
                    cmd.Parameters.AddWithValue("@SD", DepNameTb.Text);
                    cmd.Parameters.AddWithValue("@FP", SemCb.SelectedItem);
                    cmd.Parameters.AddWithValue("@FA", FeesAmtTb.Text);
                    cmd.Parameters.AddWithValue("@PDa", DateTime.Today.Date);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Fees Paid");
                    Con.Close();
                    ShowFees();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void StIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetStName();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Homes Obj = new Homes();
            Obj.Show();
            this.Hide();
        }

        private void SalPayBtn_Click(object sender, EventArgs e)
        {
            if (SalaryAmtTb.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                string Period = SalaryPeriod.Value.Date.Month.ToString() + "/" + SalaryPeriod.Value.Date.Year.ToString();

                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into SalaryTbl(TrNum,TrName,TrSalary,SPeriod,SPDate)values(@TN,@TNa,@TS,@SP,@SPD)", Con);
                    cmd.Parameters.AddWithValue("@TN", TrIdCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@TNa", TrNameTb.Text);
                    cmd.Parameters.AddWithValue("@TS", SalaryAmtTb.Text);
                    cmd.Parameters.AddWithValue("@SP", Period);
                    cmd.Parameters.AddWithValue("@SPD", DateTime.Today.Date);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Salary Paid");
                    Con.Close();
                    ShowSalary();
                    ResetSalary();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void TrIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetTrName();
        }

        private void SalResetBtn_Click(object sender, EventArgs e)
        {
            ResetSalary();
        }

        private void FeeResetBtn_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Students Obj = new Students();
            Obj.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Departments Obj = new Departments();
            Obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Teachers Obj = new Teachers();
            Obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Courses Obj = new Courses();
            Obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Fees Obj = new Fees();
            Obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Logins obj = new Logins();
            obj.Show();
            this.Close();
        }
    }
}
