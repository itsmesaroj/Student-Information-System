﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CollegeManagementSystem
{
    public partial class Teachers : Form
    {
        public Teachers()
        {
            InitializeComponent();
            ShowTeacher();
            GetDepId();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\SAROJ MEHTA\OneDrive\Documents\College_Db.mdf"";Integrated Security=True;Connect Timeout=30");
        private void GetDepId()
        {
            Con.Open();
            SqlCommand cmd = new SqlCommand("Select DepNum from DepartmentTbl", Con);
            // SqlCommand cmd = new SqlCommand("Select DepNum from TeacherTbl", Con);
            //SqlCommand cmd = new SqlCommand("SELECT DepartmentTbl.DepNum FROM TeacherTbl INNER JOIN DepartmentTbl ON TeacherTbl.DepNum = DepartmentTbl.DepNum WHERE TeacherTbl.TrDepId = 'TrDepId'", Con);
            SqlDataReader Rdr;
            Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("DepNum", typeof(int));
            dt.Load(Rdr);
            DepIdCb.ValueMember = "DepNum";
            DepIdCb.DataSource = dt;
            Con.Close();
        }
        private void GetDepName()
        {
            Con.Open();
            string Query = "Select * from DepartmentTbl where DepNum=" + DepIdCb.SelectedValue.ToString() + "";
            // string Query = "Select * from TeacherTbl where DepNum=" + DepIdCb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(Query, Con);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                DepNameTb.Text = dr["DepName"].ToString();
            }
            Con.Close();

        }
        private void ShowTeacher()
        {
            Con.Open();
            string Query = "select * from TeacherTbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            TrDGV.DataSource = ds.Tables[0];
            Con.Close();
            Reset();
        }
        private void Reset()
        {
            DepNameTb.Text = "";
            TrAddTb.Text = "";
            GenCb.SelectedIndex = -1;
            ExpTb.Text = "";
            SalaryTb.Text = "";
            QualificationCb.SelectedIndex = -1;
            TrNameTb.Text = "";

        }
        private void Teachers_Load(object sender, EventArgs e)
        {
            // Nothing
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (TrNameTb.Text == "" || TrAddTb.Text == "" || DepNameTb.Text == "" || GenCb.SelectedIndex == -1 || DepNameTb.Text == "" || QualificationCb.SelectedIndex == -1 || DepIdCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into TeacherTbl(TrName,TrDOB,TrGen,TrAdd,TrQual,TrExp,TrDepId,TrDepName,TrSalary)values(@TN,@TDO,@TG,@TA,@TQ,@TE,@TD,@TDN,@TS)", Con);
                    cmd.Parameters.AddWithValue("@TN", TrNameTb.Text);
                    cmd.Parameters.AddWithValue("@TDO", TrDOB.Value.Date);
                    cmd.Parameters.AddWithValue("@TG", GenCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@TA", TrAddTb.Text);
                    cmd.Parameters.AddWithValue("@TQ", QualificationCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@TE", ExpTb.Text);
                    cmd.Parameters.AddWithValue("@TD", DepIdCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@TDN", DepNameTb.Text);
                    cmd.Parameters.AddWithValue("@TS", SalaryTb.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Teacher Added");
                    Con.Close();
                    ShowTeacher();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void DepIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetDepName();
        }

        private void label3_Click(object sender, EventArgs e) //Department Name
        {
            Departments Obj = new Departments();
            Obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e) //Students Name
        {
            Students Obj = new Students();
            Obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)  //teacher Name
        {
            Teachers Obj = new Teachers();
            Obj.Show();
            this.Hide();
        }
        int Key = 0;
        private void TrDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            TrNameTb.Text = TrDGV.SelectedRows[0].Cells[1].Value.ToString();
            TrDOB.Text = TrDGV.SelectedRows[0].Cells[2].Value.ToString();
            GenCb.SelectedItem = TrDGV.SelectedRows[0].Cells[3].Value.ToString();
            TrAddTb.Text = TrDGV.SelectedRows[0].Cells[4].Value.ToString();
            QualificationCb.SelectedValue = TrDGV.SelectedRows[0].Cells[5].Value.ToString();
            ExpTb.Text = TrDGV.SelectedRows[0].Cells[6].Value.ToString();
            DepIdCb.Text = TrDGV.SelectedRows[0].Cells[7].Value.ToString();
            DepNameTb.Text = TrDGV.SelectedRows[0].Cells[8].Value.ToString();
            SalaryTb.Text = TrDGV.SelectedRows[0].Cells[9].Value.ToString();

            if (TrNameTb.Text == "")
            {
                Key = 0;

            }
            else
            {
                Key = Convert.ToInt32(TrDGV.SelectedRows[0].Cells[0].Value.ToString());
            }
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            if (TrNameTb.Text == "" || TrAddTb.Text == "" || DepNameTb.Text == "" || GenCb.SelectedIndex == -1 || DepNameTb.Text == "" || QualificationCb.SelectedIndex == -1 || DepIdCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Update TeacherTbl Set TrName=@TN,TrDOB=@TDO,TrGen=@TG,TrAdd=@TA,TrQual=@TQ,TrExp=@TE,TrDepId=@TD,TrDepName=@TDN,TrSalary=@TS where TrNum=@TKey", Con);
                    cmd.Parameters.AddWithValue("@TN", TrNameTb.Text);
                    cmd.Parameters.AddWithValue("@TDO", TrDOB.Value.Date);
                    cmd.Parameters.AddWithValue("@TG", GenCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@TA", TrAddTb.Text);
                    cmd.Parameters.AddWithValue("@TQ", QualificationCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@TE", ExpTb.Text);
                    cmd.Parameters.AddWithValue("@TD", DepIdCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@TDN", DepNameTb.Text);
                    cmd.Parameters.AddWithValue("@TS", SalaryTb.Text);
                    cmd.Parameters.AddWithValue("@TKey", Key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Teacher Updated");
                    Con.Close();
                    ShowTeacher();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            if (Key == 0)
            {
                MessageBox.Show(" Select The Student");
            }
            else
            {
                try
                {
                    Con.Open();
                    SqlCommand cmd = new SqlCommand("Delete TeacherTbl where TrNum=@TKey", Con);
                    cmd.Parameters.AddWithValue("@TKey", Key);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Teacher Deleted");
                    Con.Close();
                    ShowTeacher();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Homes Obj = new Homes();
            Obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Courses Obj = new Courses();
            Obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Fees Obj = new Fees();
            Obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Logins obj = new Logins();
            obj.Show();
            this.Close();
        }


    }
}
